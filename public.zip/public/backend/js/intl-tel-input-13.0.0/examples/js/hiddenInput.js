$("#phone").intlTelInput({
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js" // just for formatting/placeholders etc
});
